import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:pipework/constants.dart';

class AuthService {
  Future<dynamic> register({
    required String email,
    required String password,
    required String username,
  }) async {
    try {
      var url = Uri.parse(
          "https://celd.josephadegbola.com/wp-json/route/v2/addcustomer");
      Map body = {
        "email": email,
        "password": password,
        "username": username,
      };

      var response = await http.post(url, body: body);

      if (response.statusCode == 200) {
        dynamic result = jsonDecode(response.body);
        return result;
      }
      if (response.statusCode == 400) {
        dynamic result = jsonDecode(response.body);
        return result;
      }
    } catch (e) {
      debugPrint(e.toString());
    }
  }


  login({required String password, required String username}) async {
    try {
      var url = Uri.parse(
          "https://celd.josephadegbola.com/wp-json/api/v2/user-auth/");

      Map body = {
        "user_login": username,
        "user_password": password,
      };


      var response = await http.post(url, body: body);


      if (response.statusCode == 200) {
        dynamic result = jsonDecode(response.body);
        return result;
      }
    } catch (e) {
      debugPrint(e.toString());
    }
  }


  //  walletbalance

  Future getWalletBalance(String email) async {
    var url = Uri.parse(
        Constants.GET_WALLET_BALANCE + email);

    var response = await http.get(url);
    if (response.statusCode == 200) {
      dynamic result = jsonDecode(response.body);
      return result;
    }
    if (response.statusCode == 400) {
      dynamic result = jsonDecode(response.body);
      return result;
    }
  }
}




