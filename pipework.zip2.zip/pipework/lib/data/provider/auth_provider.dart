import 'package:flutter/material.dart';
import 'package:pipework/data/services/auth_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
class AuthProvider extends ChangeNotifier {
  bool isLoggedIn = false;
  String? username;
  String? password;
  String? email;


  final service = AuthService();

  set isRegistered(bool isRegistered) {}


  Future login(String username,
      String password, {
        bool isRegistered = false,
      }) async {
    this.username = username;
    this.password = password;
    this.isRegistered = isRegistered;
    var result = await service.login(password: password, username: username);
    print('result: ');
    print(result);

    if (result['status'] == 200) {
      getWalletBalance(username);
      this.username = username;
      this.password = password;
      isLoggedIn = true;
      notifyListeners();
      return 'user logged in';
    }

    if (result['status'] == 401) {
      throw Exception('login not successful');
    }

    return result;
  }

  //Getting and saving wallet balance in the local storage

  Future getWalletBalance(String email) async{
    SharedPreferences preferences = await SharedPreferences.getInstance();
    this.email = email;
     var result = await service.getWalletBalance(email);
     var balance = result['balance'];
     debugPrint("Walet balance $balance");
     preferences.setInt('walletBalance', balance);

  }

  Future register(String username,
      String email,
      String password, {
        bool isLoggedIn = false,
      }) async {
    this.username = username;
    this.password = password;
    this.isLoggedIn = isLoggedIn;
    var result = await service.register(
        email: email, password: password, username: username);

    if (result['code'] == 200) {
      notifyListeners();
      return 'user registered';
    }

    if (result['code'] == 406) {
      throw Exception('registration not successful');
    }

    return result;
  }

  logout() {
    username = null;
    password = null;
    isLoggedIn = false;
    notifyListeners();
  }


}


  final authProvider = AuthProvider();
