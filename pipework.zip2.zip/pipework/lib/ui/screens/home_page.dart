import 'package:flutter/material.dart';
import 'package:pipework/ui/widget/swipe_detector.dart';
import 'package:flutter_paystack/flutter_paystack.dart';
import 'package:pipework/data/provider/storage_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.title});

  final String title;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // int _counter = 0;
  int? _balanceRetrieved = 0;
  int _counter = 50;
  bool _refresh= false;

  @override
  void didChangeDependencies(){
    if(_refresh){
      setState(() {
        _balanceRetrieved = StorageProvider.instance.getInt('walletBalance');
        _counter = _balanceRetrieved!;
      });
    }

    super.didChangeDependencies();
  }

  @override
  void initState() {
    final counter = StorageProvider.instance.getDouble('_counter');
    setState(() {
      _balanceRetrieved = StorageProvider.instance.getInt('walletBalance');
      _counter = _balanceRetrieved!;
    });
    if (counter != null) {
      _counter = counter as int;
    }

    super.initState();
  }

void _incrementCounter() {
  setState(() {
    _counter--;
  });
}

@override
Widget build(BuildContext context) {
final Object? refresh  = ModalRoute.of(context)?.settings.arguments;
  if(refresh != null){
    _refresh = _refresh;
  }
  return Scaffold(backgroundColor: Colors.grey,

    appBar: AppBar(
      actions: [Text(_counter.toString())],
      automaticallyImplyLeading: false,
      title: Text(widget.title),
    ),
    body: SwipeDetector(
      onSwipeUp: () {
        debugPrint("swiped");
        _incrementCounter();
  },

  child: Center(
  child: Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          const Text(
            'Wallet balance is:',

          ),
          Text(
          'N ' + '$_counter',
            style: Theme.of(context).textTheme.headline4,
          ),

        ],

      ),
  ),
  )

    ),
    floatingActionButton: FloatingActionButton(
      onPressed: (){
    Navigator.of(context).pushNamed('/payment2');
    },
      tooltip: 'Fund Wallet',
      child: Center(child: SizedBox(child: const Icon(Icons.monetization_on_outlined)))

    ),
  );
}

Future<double?> getWalletBalanceFromSharedPreference()async{
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var balance= preferences.getDouble('walletBalance');
    return balance;
}


}








