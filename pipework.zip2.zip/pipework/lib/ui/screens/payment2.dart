import 'package:flutter/material.dart';
import 'package:flutter_paystack/flutter_paystack.dart';
import 'package:http/http.dart' as http;
import 'package:pipework/app.dart';
import 'package:pipework/constants.dart';
import 'package:pipework/data/provider/storage_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:math';


class WalletScreen extends StatefulWidget {
  @override
  _WalletScreenState createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  int walletBalance = 0;
  int enteredAmount = 0;
  String enteredEmail = 'justin@gmail.com';
  String accesscode= '';
  var paystackPublicKey = Constants.YOUR_PAYSTACK_PUBLIC_KEY;
  final plugin = PaystackPlugin();
  TextEditingController amountController = new TextEditingController();

  @override
  void initState() {
    plugin.initialize(publicKey: paystackPublicKey);
    setState(() {
      walletBalance = StorageProvider.instance.getInt('walletBalance')!;
    });
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: Icon(Icons.arrow_back), onPressed: (){ Navigator.pop(context, true);},) ,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Wallet Balance: ₦ $walletBalance'),
          _createTextField(hintText: 'Amount' , controller: amountController),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(
                  vertical: 16,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),

                ),
              fixedSize: Size(MediaQuery.of(context).size.width, 50)

            ),
            onPressed: () async {
              String? generate_url = Constants.GENERATE_PAYSTACK_REFERENCE;
              var url= Uri.parse(generate_url);
              // Generate payment reference
              var response = await http.post(url,
                  body: jsonEncode({
                    'amount': int.parse(amountController.text)  ,
                    //       ..amount = int.parse(_amountController.text) * 100

                    'email': enteredEmail,
                  }),
                  headers: {
                    'Content-Type': 'application/json',
                  }
              );
              var responseData = jsonDecode(response.body);
              print(responseData);
              String reference = responseData['data']['reference'] + Random().nextInt(1000).toString();


              try{
                // Open Paystack payment gateway
                Charge charge = Charge()
                  ..amount = int.parse(amountController.text)  * 100
                  ..reference = reference
                  ..email = "justin@gmail.com";
                accesscode = responseData['data']['access_code'];
                CheckoutResponse checkoutResponse = await plugin.checkout(
                  context,
                  charge: charge,
                  method: CheckoutMethod.card,

                );
                // Verify payment reference
                if (checkoutResponse.message == 'Success')  {
                  String? verify_url =  Constants.VERIFY_PAYSTACK_REFERENCE +reference ;
                  var url= Uri.parse(verify_url);
                  var verificationResponse =
                  await http.get(url);
                  var verificationResponseData = jsonDecode(verificationResponse.body);
                  debugPrint(verificationResponseData.toString());
                  if (verificationResponseData['status'] == true) {
                    setState(() {
                      walletBalance = walletBalance + int.parse(amountController.text) ;
                      StorageProvider.instance.setInt('walletBalance', walletBalance);
                    });

                  }
                }
              }
              catch(e){
                debugPrint("Error here");
                debugPrint(e.toString());
              }

            },
            child: Text('Fund My Wallet'),
          )
        ],
      ),
    );
  }

  Widget _createTextField({
    required String hintText,
    TextEditingController? controller,
    bool obscureText = false,
    String? Function(String? value)? validator,
  }) {

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white,
      ),
      child: TextFormField(
        keyboardType: TextInputType.number,
        obscureText: obscureText,
        validator: validator,
        controller: controller,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.white),
            borderRadius: BorderRadius.circular(12),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.white),
            borderRadius: BorderRadius.circular(12),
          ),
          fillColor: Colors.white,
          hintText: hintText,
        ),
      ),
    );
  }
}
