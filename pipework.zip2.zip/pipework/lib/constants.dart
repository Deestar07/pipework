
class Constants {
  static const String YOUR_PAYSTACK_PUBLIC_KEY = 'pk_test_ae8cc2e28833d716c4458aee81fab3d738a9fda9';

  static load({required String fileName}) {}

  static const String VERIFY_PAYSTACK_REFERENCE = 'http://147a-41-184-177-9.ngrok.io/verify/';

  static const String GENERATE_PAYSTACK_REFERENCE =  'http://147a-41-184-177-9.ngrok.io/get-reference';

  static const String GET_WALLET_BALANCE ='http://147a-41-184-177-9.ngrok.io/wallet/:email';
}
